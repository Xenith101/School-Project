﻿Imports System.Data.OleDb
Public Class Snapchat

    Dim increase As Integer = 4

    Dim CON As New OleDb.OleDbConnection 'OLE - Object Linking and Embedding. CON - connection object
    Dim dbProvider As String
    Dim dbSource As String
    Dim MyDocumentsFolder As String
    Dim TheDatabase As String
    Dim FullDatabasePath As String
    Dim command As String

    Dim ds As New DataSet
    Dim da As OleDb.OleDbDataAdapter
    Dim sql As String


    Private Sub OwnDatabase_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'assigns the provider 
        dbProvider = "PROVIDER=Microsoft.Jet.OLEDB.4.0;"
        'Specifies the folder path for the database .mdb file. Can be found in the 'SpecialFolder' Documents under the path specified below. 
        MyDocumentsFolder = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        TheDatabase = "/Passwords.mdb"
        FullDatabasePath = MyDocumentsFolder & TheDatabase 'TheDatabase is the filepath to the Access database 

        dbSource = "data source = " & FullDatabasePath
        'assigns the value of dbProvider and dbSource to the connection string
        CON.ConnectionString = dbProvider & dbSource

        'opens the connection object 
        CON.Open()

        'Assigns an SQL statement 
        sql = "select * from Fields"

        da = New OleDb.OleDbDataAdapter(sql, CON)
        da.Fill(ds, "Passwords")

        'closes the connection object
        CON.Close()
        'Calls the sub which populates textboxes with relevant information 
        Display()

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles updateBtn.Click
        'opens the connection object 
        CON.Open()
        'Parameterise SQL query which updates each field with it's specified textbox text. i.e. The field [FirstName] in the database -
        'will be updated with the text value in the textbox FirstnameTxt. 
        command = "update Fields set [FirstName]='" & firstnameTxt.Text & "', [LastName]='" & LastnameTxt.Text & "', [Username]='" & usernameTxt.Text & "', [Telephone]='" & telephoneTxt.Text & "', [Email]='" & emailTxt.Text & "', [DOB]='" & dobTxt.Text & "', [Address]='" & addressTxt.Text & "', [Password]='" & passwordTxt.Text & "' where [ID]=" & TextBox9.Text & ""
        Dim cmd As OleDbCommand = New OleDbCommand(command, CON)
        MsgBox("Information Updated")
        'Try Catch to handle unexpect runtime exceptions. 
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub newpassbtn_Click(sender As Object, e As EventArgs) Handles newpassbtn.Click
        passwordTxt.Clear()
        'Pool of letters which a password will be formed out of.
        Dim pool As String = "abcdefghujklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@!?"
        Dim count = 0
        Dim Rnd As New Random
        'Passwordtxt is assigned a random string of characters from the pool which is then entered into Passwordtxt.text -
        'which has been chosen within a range of 0 to the length of the pool (65)
        While count <= 12
            passwordTxt.Text = passwordTxt.Text & pool(Rnd.Next(0, pool.Length))
            count = count + 1
        End While
    End Sub
    Private Sub PasswordHover(sender As Object, e As EventArgs) Handles passwordTxt.MouseHover
        'When the user cusor hovers over passwordtxt and its "*" password character it will assign a blank value to PasswordChar - 
        'which will make the password visible to the user.
        passwordTxt.PasswordChar = ""

    End Sub

    Private Sub PasswordUnhover(sender As Object, e As EventArgs) Handles passwordTxt.MouseLeave
        'When the users cursor is no longer hovering over the password character the value "*" is assigned to PasswordChar - 
        'making it impossible to read again. 
        passwordTxt.PasswordChar = "*"

    End Sub
    Private Sub Display()
        'This assigns the value of Item(n) in the "Passwords" database to the appropriate textbox. This sub is then called -
        'in the code which then causes the textboxes to be populated with information on loading of the form
        firstnameTxt.Text = ds.Tables("Passwords").Rows(increase).Item(1).ToString
        LastnameTxt.Text = ds.Tables("Passwords").Rows(increase).Item(2).ToString
        usernameTxt.Text = ds.Tables("Passwords").Rows(increase).Item(3).ToString
        telephoneTxt.Text = ds.Tables("Passwords").Rows(increase).Item(4).ToString
        emailTxt.Text = ds.Tables("Passwords").Rows(increase).Item(5).ToString
        dobTxt.Text = ds.Tables("Passwords").Rows(increase).Item(6).ToString
        addressTxt.Text = ds.Tables("Passwords").Rows(increase).Item(7).ToString
        passwordTxt.Text = ds.Tables("Passwords").Rows(increase).Item(8).ToString
        TextBox9.Text = ds.Tables("Passwords").Rows(increase).Item(0).ToString
    End Sub
End Class

