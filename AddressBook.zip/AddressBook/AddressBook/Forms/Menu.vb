﻿Imports System.Data.OleDb
Public Class MMenu
    'Con is assigned with the connection string to the Login Database 
    Dim CON As New OleDbConnection(My.Settings.LoginConnectionString)

    Private Sub loginBtn_Click(sender As Object, e As EventArgs) Handles loginBtn.Click

        'This is a check for the input of credentials. If the user does not input a username or password then an error message appears. 
        If usernameTxt.Text = Nothing Or passwordTxt.Text = Nothing Then
            MsgBox("enter valid credentials.")
        End If
        'a check if the connection to the database is closed. If it is then it is opened again.
        If CON.State = ConnectionState.Closed Then
            CON.Open()
        End If
        'This command uses an SQL query in which the fields 'username' and 'password' are checked for a matching username and password -
        'to what the user entered into the textboxes. 
        Using Command As New OleDbCommand("SELECT COUNT(*) FROM Users WHERE Username = @Username AND Password = @Password", CON)
            Command.Parameters.AddWithValue("@Username", OleDbType.VarChar).Value = usernameTxt.Text.Trim
            Command.Parameters.AddWithValue("@Password", OleDbType.VarChar).Value = passwordTxt.Text.Trim

            Dim count = Convert.ToInt32(Command.ExecuteScalar())

            'If valid credentials are found within the Login database a message appears and the user is taken to the Primary screen. 
            If count > 0 Then
                MessageBox.Show("login found")
                Me.Hide()
                Passwords.Show()
            Else
                'If there are no credentials which match what the user has entered then a message box appears and the user is prompted -
                'to enter valid credentials. 
                MsgBox("enter valid credentials.", MsgBoxStyle.Exclamation)
            End If
        End Using
    End Sub

    Private Sub Admin_Click(sender As Object, e As EventArgs) Handles Admin.Click
        'Admin button which allows for instant access to those with appropriate permission. 

        Passwords.Show()


    End Sub
    Private Sub CreateAccBtn_Click(sender As Object, e As EventArgs) Handles CreateAccBtn.Click
        'This button takes the user to the account creation form. 
        Me.Hide()
        CreateAccount.Show()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'This hidden button reveals an admin button which then allows for instant access to the primary portion of the 
        'Without having to enter any credentials. Button Located in bottom right of the first form.
        Admin.Visible = True
    End Sub
End Class