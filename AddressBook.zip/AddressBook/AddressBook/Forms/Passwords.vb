﻿Public Class Passwords
    Dim currentBtn As Button
    Dim currentChildForm As Form
    Dim borderbtn As Panel
    Private Sub Passwords_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'New instance of a Panel class is assigned to borderbtnm
        borderbtn = New Panel
        borderbtn.Size = New Size(7, 61)
        menuPanel.Controls.Add(borderbtn)

    End Sub

    Private Sub Activatebutton(senderBtn As Object, Forecolour As Color, Backcolour As Color)

        If senderBtn IsNot Nothing Then
            'Calling Deactivatebutton here allows for the previously clicked button to return to it's previous state. 
            Deactivatebutton()
            'BUTTON
            currentBtn = CType(senderBtn, Button)
            currentBtn.BackColor = colours.BrighterRed
            'Forecolour changes the colour of the text within the border buttons
            currentBtn.ForeColor = Forecolour
            currentBtn.TextAlign = ContentAlignment.MiddleCenter
            formtitleLabel.ForeColor = Forecolour

            'BORDER on the left side of the button
            'Backcolour changes the colour of the border of the left side of the button.
            'Forecolour and Backcolour have been separated to have individual control over the colours of each section. 
            borderbtn.BackColor = Backcolour
            borderbtn.Location = New Point(0, currentBtn.Location.Y)
            borderbtn.Visible = True
            borderbtn.BringToFront()
        End If

    End Sub

    Private Sub Deactivatebutton()
        'If the current button is active then the colour values for both Forecolour and BackColour whis the button text and left hand border -
        'the text is the alligned to the middle left. 
        If currentBtn IsNot Nothing Then
            currentBtn.BackColor = colours.Red
            currentBtn.ForeColor = colours.Null
            currentBtn.TextAlign = ContentAlignment.MiddleLeft
        End If

    End Sub

    Private Sub OpenChildForm(childform As Form)

        'If current child form is not empty then the current form is to be closed. 
        'This will allow for a single form to be open within the main panel as opposed to multiple forms -
        'opening on top of eachother. 

        If currentChildForm IsNot Nothing Then
            currentChildForm.Close()
        End If
        currentChildForm = childform

        'This declares that the childform within the main panel isn't top level, should have no border since it is within another form -
        'and is docked to fill the rest of the empty space. 
        childform.TopLevel = False
        childform.FormBorderStyle = FormBorderStyle.None
        childform.Dock = DockStyle.Fill
        mainPanel.Controls.Add(childform)
        'This associates form data to the panel. 
        mainPanel.Tag = childform
        childform.BringToFront()
        childform.Show()
        formtitleLabel.Text = childform.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'This assigns preset colours to the Backcolour and Forecolour of the currently selected button.
        'The colours are chosen and set in colours.vb
        Activatebutton(sender, colours.Google1, colours.Google2)
        'This calls the method that opens a childform within the primary form. 
        OpenChildForm(New Gmail)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Activatebutton(sender, colours.Discord1, colours.Discord2)
        OpenChildForm(New Discord)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Activatebutton(sender, colours.Spotify1, colours.Spotify2)
        OpenChildForm(New Spotify)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Activatebutton(sender, colours.Instagram1, colours.Instagram1)
        OpenChildForm(New Instagram)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Activatebutton(sender, colours.Snapchat1, colours.Snapchat1)
        OpenChildForm(New Snapchat)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Activatebutton(sender, colours.Twitter1, colours.Twitter1)
        OpenChildForm(New Twitter)
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Activatebutton(sender, colours.Steam1, colours.Steam1)
        OpenChildForm(New Steam)
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Activatebutton(sender, colours.Origin1, colours.Origin2)
        OpenChildForm(New Origin)
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Activatebutton(sender, colours.Epic1, colours.Epic1)
        OpenChildForm(New Epic)
    End Sub

    Private Sub Logout_Click(sender As Object, e As EventArgs) Handles Logout.Click
        'When the user presses the Log Out button the current form closes and the original menu is shown. 
        Me.Close()
        MMenu.Show()
    End Sub
End Class