﻿Imports System.Data.OleDb
Public Class CreateAccount
    'Con is assigned with the connection string to the Login Database 
    Dim CON As New OleDbConnection(My.Settings.LoginConnectionString)

    Private Sub CreateAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'When the form loads both text boxes are cleared of the previous text.
        usernameTxt.Clear()
        passwordTxt.Clear()
    End Sub
    Private Sub RegisterBtn_Click(sender As Object, e As EventArgs) Handles RegisterBtn.Click
        'This is a check for the input of credentials. If the user does not input a username or password then an error message appears. 
        If usernameTxt.Text = Nothing Or passwordTxt.Text = Nothing Then
            MsgBox("enter valid credentials.", MsgBoxStyle.Exclamation)
        End If
        'a check if the connection to the database is close. If it is then it is opened again.
        If CON.State = ConnectionState.Closed Then
            CON.Open()
        End If


        'This command uses an SQL query in which the fields 'username' and 'password' added to with the text that the user -
        'entered into usernameTxt and passwordTxt. 
        Using create As New OleDbCommand("INSERT into Users([Username], [Password]) VALUES(@Username, @Password)", CON)
            create.Parameters.AddWithValue("@Username", OleDbType.VarChar).Value = usernameTxt.Text.Trim
            create.Parameters.AddWithValue("@Password", OleDbType.VarChar).Value = passwordTxt.Text.Trim

            'if a change within the database occurs then a message is returned stating that the account creation has been successful. 
            If create.ExecuteNonQuery Then
                MsgBox("Account created successfully", MsgBoxStyle.MsgBoxRight)
                'After creation the user is then returned to the log in screen so that they can continue.
                Me.Hide()
                MMenu.Show()
            Else
                'if a change does not occur within the database then an error is displayed 
                MsgBox("Registration was unsuccessful")
            End If
        End Using
        CON.Close()
    End Sub

    Private Sub returnBtn_Click(sender As Object, e As EventArgs) Handles returnBtn.Click
        'THe use can press this button to return to the log in screen. 
        Me.Hide()
        MMenu.Show()
    End Sub
End Class