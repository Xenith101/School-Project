﻿Public Structure colours
    'Used a structure in order to easily be able to choose preset colours for the left pane buttons. 
    'This also allowed for the incorporation of a structure which allowed for the ease if reusing colours easily without having to use aRGB values.

    Public Shared Main As Color = Color.FromArgb(255, 255, 255) 'White
    Public Shared BrighterRed As Color = Color.FromArgb(50, 12, 12) 'Primary Bright Red
    Public Shared Null As Color = Color.FromArgb(80, 80, 80) 'Unused Button
    Public Shared Red As Color = Color.FromArgb(33, 12, 12) 'Unused Button

    Public Shared Discord1 As Color = Color.FromArgb(114, 140, 232) 'Light Discord Software RGB Value
    Public Shared Discord2 As Color = Color.FromArgb(91, 110, 176) ' Dark Discord Software RGB Value

    Public Shared Spotify1 As Color = Color.FromArgb(30, 215, 96) ' Light Spotify Software RGB Value
    Public Shared Spotify2 As Color = Color.FromArgb(29, 185, 84) ' Dark Spotify Software RGB Value 

    Public Shared Google2 As Color = Color.FromArgb(178, 68, 53) ' Light Google Software RGB Value
    Public Shared Google1 As Color = Color.FromArgb(180, 186, 196) ' Dark Google Software RGB Value 

    Public Shared Instagram1 As Color = Color.FromArgb(195, 42, 163) ' Dark Instagram Software RGB Value 
    Public Shared Instagram2 As Color = Color.FromArgb(255, 220, 125) ' Light Instagram Software RGB Value 

    Public Shared Snapchat1 As Color = Color.FromArgb(255, 252, 0) ' Light Snapchat Software RGB Value 
    Public Shared Snapchat2 As Color = Color.FromArgb(255, 255, 255) ' Light Snapchat Software RGB Value 

    Public Shared Twitter1 As Color = Color.FromArgb(29, 161, 242) ' Light Twitter Software RGB Value 
    Public Shared Twitter2 As Color = Color.FromArgb(225, 232, 237) ' Light Twitter Software RGB Value 

    Public Shared Steam2 As Color = Color.FromArgb(23, 26, 33) ' Light Steam Software RGB Value 
    Public Shared Steam1 As Color = Color.FromArgb(199, 213, 224) ' Light Steam Software RGB Value 

    Public Shared Origin1 As Color = Color.FromArgb(241, 90, 35) ' Light Origin Software RGB Value 
    Public Shared Origin2 As Color = Color.FromArgb(109, 110, 112) ' Light Origin Software RGB Value 

    Public Shared Epic1 As Color = Color.FromArgb(255, 255, 255) ' Light Epic Software RGB Value 
    Public Shared Epic2 As Color = Color.FromArgb(0, 0, 0) ' Light Epic Software RGB Value 

End Structure
